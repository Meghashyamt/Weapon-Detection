# Weapon-Detection-And-Classification-Using-Deep-Learning
Weapon Detection &amp; Classification through CCTV surveillance using Deep Learning-CNNs.
<hr>
The classifier works best with any number of frames saved in this folder.<br>
Note : GPU is essential.
