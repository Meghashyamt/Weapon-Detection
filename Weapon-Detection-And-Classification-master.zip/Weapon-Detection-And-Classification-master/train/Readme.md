# Weapon-Detection-And-Classification-Using-Deep-Learning
Weapon Detection &amp; Classification through CCTV surveillance using Deep Learning-CNNs.
<hr>
<b>>>Datasets:-</b><br>

- Knife - [3,641 images]- [link](http://kt.agh.edu.pl/~matiolanski/KnivesImagesDatabase/) + some other found while scrapping the internet.

- Long Gun - [2,497 images]- [link](http://www.imfdb.org/wiki/Main_Page) + some other found while scrapping the internet.

- Small Gun - [3,876 images]- [link](https://sci2s.ugr.es/sites/default/files/files/TematicWebSites/WeaponsDetection/BasesDeDatos/Test.zip)

*************************************************

**Total size of dataset: '10,014 images'**

*************************************************

Extract the images and sort them in the corresponding folders.

