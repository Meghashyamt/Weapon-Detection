Presentation Link -> https://docs.google.com/presentation/d/1LqsclbcXt5wuGK8mVzsfMmE5cuOsiWnAYZ0flnVxnaE/edit?usp=sharing
