Used Matterport Mask RCNN implementation available publicly at https://github.com/matterport/Mask_RCNN


Mask RCNN implementation files.
The annotated dataset for 1751 images can be found at the drive link--
https://drive.google.com/uc?id=13VIZ0qgxhlyBQuWPJgm_bk0zfDjMXh9R
