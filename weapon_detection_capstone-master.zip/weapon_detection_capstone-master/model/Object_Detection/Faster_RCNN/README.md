Faster RCNN model implementation.
