# YOLO model implementation files.

### Darknet: 
https://pjreddie.com/darknet/yolo/
### Darkflow: 
https://github.com/thtrieu/darkflow
