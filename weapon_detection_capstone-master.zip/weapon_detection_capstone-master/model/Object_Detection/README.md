Object detection models.
