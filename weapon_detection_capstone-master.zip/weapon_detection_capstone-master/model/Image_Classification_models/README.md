All Image classification models will be stored in this repository.
