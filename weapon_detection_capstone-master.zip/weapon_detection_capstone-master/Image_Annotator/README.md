Annotation tool used:
VGG Image Annotator (VIA) available at http://www.robots.ox.ac.uk/~vgg/software/via/
