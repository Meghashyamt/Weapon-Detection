Download the dataset under heading - <b>Handgun dataset for the region proposals approach</b> - from link below</br>
https://sci2s.ugr.es/weapons-detection </br>
The training dataset, appropriate for the detection task, contains 3000 images of guns with rich context.
